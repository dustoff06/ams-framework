"""
Core AMS framework classes.
"""
import cupy as cp
import torch
import torch.nn as nn
import torch.utils.dlpack as torch_dlpack
from typing import Optional, Dict, Any, Union
import re
import math

# Import from utils
from .utils import (
    gpu_poly_features,
    _vectorized_forward_selection,
    _fast_cv_score,
)

# Define the missing variables
_Array = Union[cp.ndarray, torch.Tensor]
_HAS_CUPY = True  # Since you're using CuPy

class VectorizedAdaptiveMethodSelector:
    """Adaptive Method Selector with GPU batch processing (CuPy + Torch OLS)."""

    def __init__(self, max_degree=3, max_interaction_order=2, tolerance=1e-4, verbose=False):
        self.max_degree = int(max_degree)
        self.max_interaction_order = int(max_interaction_order)
        self.tolerance = float(tolerance)
        self.verbose = verbose
        self.selected_method = None
        self.method_scores = {}
        self.final_model = None

    def fit(self, X, y):
        if self.verbose:
            print("=== Vectorized AMS Analysis (GPU) ===")

        self.method_scores = self._vectorized_analyze_characteristics(X, y)
        recommended_method, confidence = self._make_method_decision(self.method_scores)

        if self.verbose:
            print(f"Recommended: {recommended_method} (confidence: {confidence:.3f})")

        if recommended_method == 'APS':
            self.selected_method = 'APS'
            self.final_model = VectorizedAPS(self.max_degree, self.max_interaction_order, self.tolerance, False)
            self.final_model.fit(X, y)

        elif recommended_method == 'MAPS':
            self.selected_method = 'MAPS'
            self.final_model = VectorizedMAPS(self.max_degree, self.max_interaction_order, self.tolerance, False)
            self.final_model.fit(X, y)

        else:  # BOTH_TEST
            if self.verbose:
                print("Testing both methods (GPU)...")
            aps_model = VectorizedAPS(self.max_degree, self.max_interaction_order, self.tolerance, False)
            aps_model.fit(X, y)
            aps_pred = aps_model.predict(X)
            aps_score = self._r2_cp(cp.asarray(y), cp.asarray(aps_pred))

            maps_model = VectorizedMAPS(self.max_degree, self.max_interaction_order, self.tolerance, False)
            maps_model.fit(X, y)
            maps_pred = maps_model.predict(X)
            maps_score = self._r2_cp(cp.asarray(y), cp.asarray(maps_pred))

            if self.verbose:
                print(f"APS R²: {aps_score:.4f}, MAPS R²: {maps_score:.4f}")

            if aps_score > maps_score:
                self.selected_method = 'APS'
                self.final_model = aps_model
            else:
                self.selected_method = 'MAPS'
                self.final_model = maps_model

        return self

    def predict(self, X):
        if self.final_model is None:
            raise ValueError("Model must be fitted first")
        return self.final_model.predict(X)

    # ---------------- GPU characteristic analysis ----------------

    def _vectorized_analyze_characteristics(self, X, y):
        X_cp = cp.asarray(X)
        y_cp = cp.asarray(y).reshape(-1)

        scores = {}
        scores['multiplicative_evidence']   = self._vectorized_multiplicativity_test(X_cp, y_cp)
        scores['interaction_strength']      = self._vectorized_interaction_test(X_cp, y_cp)
        scores['multiplicative_separability']= self._vectorized_separability_test(X_cp, y_cp)
        ymax = float(cp.max(y_cp))
        ymin = float(cp.min(y_cp))
        scores['dynamic_range'] = ymax / max(ymin, 1e-8)
        return scores

    def _vectorized_multiplicativity_test(self, X_cp, y_cp):
        try:
            n = int(y_cp.size)
            if n < 20:
                return 0.5

            ymax = float(cp.max(y_cp))
            ymin = float(cp.min(y_cp))
            dynamic_range = ymax / max(ymin, 1e-8)
            if dynamic_range < 3.0:
                return 0.0

            n_bootstrap = 5
            n_samples = min(n, max(50, n // 2))

            rng = cp.random.default_rng(42)
            improvement_ratios = []

            for _ in range(n_bootstrap):
                idx = rng.integers(0, n, size=n_samples, endpoint=False)
                idx_cp = cp.asarray(idx)
                Xb = X_cp[idx_cp]
                yb = y_cp[idx_cp]

                # Original space OLS
                lr1 = TorchLinearRegression(fit_intercept=True, device="cuda")
                lr1.fit(Xb, yb)
                yhat1 = lr1.predict(Xb)  # numpy
                yb_cp = cp.asnumpy(yb)
                res1 = cp.mean((yb_cp - yhat1)**2)

                # Log space (only if all positive)
                if float(cp.min(yb)) > 0.0:
                    log_yb = cp.log(yb)
                    lr2 = TorchLinearRegression(fit_intercept=True, device="cuda")
                    lr2.fit(Xb, log_yb)
                    log_pred = lr2.predict(Xb)          # numpy
                    yhat2 = cp.exp(log_pred)
                    res2 = cp.mean((yb_cp - yhat2)**2)
                    ratio = res1 / max(res2, 1e-8)
                else:
                    ratio = 0.5

                improvement_ratios.append(ratio)

            ratios = cp.asarray(improvement_ratios, dtype=float)
            med = float(cp.median(ratios))
            std = float(cp.std(ratios))
            if std > 0.5:
                med *= 0.8

            if   med > 3.0: mult = 0.9
            elif med > 2.0: mult = 0.8
            elif med > 1.5: mult = 0.6
            elif med < 0.6: mult = 0.1
            elif med < 0.8: mult = 0.3
            else:           mult = 0.4

            if dynamic_range > 20:
                mult = min(1.0, mult + 0.15)
            elif dynamic_range > 10:
                mult = min(1.0, mult + 0.10)
            return mult

        except Exception:
            return 0.5

    def _vectorized_interaction_test(self, X_cp, y_cp):
        try:
            # degree 1 (main effects) vs full poly up to max_degree
            X_main, _ = self._gpu_poly_features(X_cp, degree=1, include_bias=False)
            X_full, _ = self._gpu_poly_features(X_cp, degree=self.max_degree, include_bias=False)

            r2_main = self._cv_r2_gpu(X_main, y_cp, k=min(5, max(2, int(y_cp.size)//10)))
            r2_full = self._cv_r2_gpu(X_full, y_cp, k=min(5, max(2, int(y_cp.size)//10)))

            r2_main = max(0.0, r2_main)
            r2_full = max(0.0, r2_full)
            if r2_full <= r2_main:
                return 0.0

            return float(min(1.0, (r2_full - r2_main) / max(1.0 - r2_main, 1e-8)))
        except Exception:
            return 0.5

    def _vectorized_separability_test(self, X_cp, y_cp):
        try:
            ymin = float(cp.min(y_cp))
            if ymin <= 0.0:
                y_pos = y_cp - ymin + 1.0
            else:
                y_pos = y_cp
            log_y = cp.log(y_pos)

            d = int(X_cp.shape[1])
            if d < 2:
                return 0.0

            # Univariate fits (degree up to 2)
            preds = []
            for j in range(d):
                Xj = X_cp[:, [j]]
                Xj_poly, _ = self._gpu_poly_features(Xj, degree=min(2, self.max_degree), include_bias=False)
                lr = TorchLinearRegression(fit_intercept=True, device="cuda")
                lr.fit(Xj_poly, log_y)
                pj = lr.predict(Xj_poly)  # numpy
                preds.append(pj)

            sum_uni = cp.sum(preds, axis=0)
            # center to avoid overcounting intercepts
            sum_uni = sum_uni - (d - 1) * float(cp.mean(cp.asnumpy(log_y)))
            r2_sep = self._r2_cp(cp.asnumpy(log_y), sum_uni)

            # Full multivariate log fit up to degree 2 (to be conservative)
            X_full, _ = self._gpu_poly_features(X_cp, degree=min(2, self.max_degree), include_bias=False)
            lr_full = TorchLinearRegression(fit_intercept=True, device="cuda")
            lr_full.fit(X_full, log_y)
            pred_full = lr_full.predict(X_full)
            r2_full = self._r2_cp(cp.asnumpy(log_y), pred_full)

            if r2_full <= 0.1:
                return 0.0
            return float(min(1.0, r2_sep / max(r2_full, 1e-8)))
        except Exception:
            return 0.5

    # ---------------- decision & metrics ----------------

    def _make_method_decision(self, scores):
        mult_evidence = scores['multiplicative_evidence']
        interaction   = scores['interaction_strength']
        separability  = scores['multiplicative_separability']
        dynamic_range = scores['dynamic_range']
        
        # More reasonable thresholds for MAPS selection
        if mult_evidence > 0.55:  # Lowered from 0.7
            return 'MAPS', mult_evidence
        
        if mult_evidence < 0.25:  # Lowered from 0.35
            return 'APS', 1 - mult_evidence
        
        # Consider dynamic range and separability with lower thresholds
        if dynamic_range > 10 and separability > 0.75:  # Much more reasonable
            return 'MAPS', separability * 0.8
        
        # Strong separability indicator
        if separability > 0.85 and dynamic_range > 5:  # Lowered thresholds
            return 'MAPS', separability
        
        # Multiplicative evidence in middle range
        if mult_evidence > 0.4:  # Give MAPS more consideration
            if separability > 0.7 or dynamic_range > 8:
                return 'MAPS', mult_evidence
        
        # Low interaction strength suggests simpler model
        if interaction < 0.3:
            return 'APS', 1 - interaction
        
        # Default to testing both methods for borderline cases
        return 'BOTH_TEST', 0.5

    def get_metrics(self):
        if self.final_model is None:
            return {"method": "VectorizedAMS", "n_features": 0, "r2": 0, "aic": 0, "score": 0}
        n_features = len(getattr(self.final_model, 'selected_features', []))
        return {"method": f"VectorizedAMS->{self.selected_method}", "n_features": n_features, "r2": 0, "aic": 0, "score": 0}

    # ---------------- small helpers ----------------

    def _cv_r2_gpu(self, X_cp, y_cp, k=3):
        n = int(X_cp.shape[0])
        if int(X_cp.shape[1]) >= 0.8*n or n < 15:
            return -10.0
    
        # Fix: use k parameter instead of undefined cv_folds
        k = int(min(k, max(2, n // 10)))
        
        # simple KFold indices
        rng = cp.random.default_rng(42)
        idx = rng.permutation(n)       # cp.ndarray of [0..n-1] permuted on GPU
        folds = cp.array_split(idx, k)
    
        r2s = []
        for i in range(k):
            val_idx = folds[i]
            trn_idx = cp.concatenate([folds[j] for j in range(k) if j != i])
            X_tr = X_cp[cp.asarray(trn_idx)]
            y_tr = y_cp[cp.asarray(trn_idx)]
            X_va = X_cp[cp.asarray(val_idx)]
            y_va = y_cp[cp.asarray(val_idx)]
    
            lr = TorchLinearRegression(fit_intercept=True, device="cuda")
            lr.fit(X_tr, y_tr)
            y_hat = lr.predict(X_va)      # numpy
            r2 = self._r2_cp(cp.asnumpy(y_va), y_hat)
            if cp.isfinite(r2):
                r2s.append(r2)
        return float(cp.mean(r2s)) if r2s else -10.0

    @staticmethod
    def _r2_cp(y_true, y_pred):
        y_true = cp.asarray(y_true).reshape(-1)
        y_pred = cp.asarray(y_pred).reshape(-1)
        ybar = y_true.mean()
        ss_res = cp.sum((y_true - y_pred)**2)
        ss_tot = cp.sum((y_true - ybar)**2)
        return 1.0 - ss_res / (ss_tot + 1e-12)
    @staticmethod
    def _gpu_poly_features(X_cp: cp.ndarray, degree: int, include_bias: bool = False):
        return gpu_poly_features(X_cp, degree, include_bias)



class VectorizedAPS:
    """Vectorized Additive Polynomial Selection (GPU/CuPy + Torch OLS)"""

    def __init__(self, max_degree=3, max_interaction_order=2, tolerance=1e-4, verbose=False):
        self.max_degree = int(max_degree)
        self.max_interaction_order = int(max_interaction_order)
        self.tolerance = float(tolerance)
        self.verbose = verbose
        self.selected_features = None           # indices within candidates
        self.final_model = None                 # TorchLinearRegression
        self._feature_names_all = None          # all poly feature names
        self._candidate_indices = None          # filtered indices (interaction <= K)

    # ---------- public API ----------
    def fit(self, X, y):
        # move to GPU 
        X_cp = cp.asarray(X)
        y_cp = cp.asarray(y).reshape(-1)

        # build polynomial features on GPU
        X_poly, feat_names = self._gpu_poly_features(X_cp, self.max_degree, include_bias=False)
        self._feature_names_all = feat_names

        # filter by max interaction order
        candidate_indices = self._filter_by_interaction_order(feat_names)
        if len(candidate_indices) == 0:
            candidate_indices = list(range(min(X_cp.shape[1], X_poly.shape[1])))

        X_cand = X_poly[:, candidate_indices]
        self._candidate_indices = candidate_indices

        # forward selection (GPU-backed CV)
        self.selected_features = self._vectorized_forward_selection(X_cand, y_cp)

        # fit final model on selected poly features (or fallback to raw X)
        from math import inf
        if self.selected_features and len(self.selected_features) > 0:
            X_final = X_cand[:, self.selected_features]
        else:
            # fallback — use raw X if nothing selected
            X_final = X_cp

        lr = TorchLinearRegression(fit_intercept=True, device="cuda")
        lr.fit(X_final, y_cp)
        self.final_model = lr

        # store absolute poly indices for prediction-time selection
        if self.selected_features and len(self.selected_features) > 0:
            abs_idxs = [candidate_indices[i] for i in self.selected_features]
        else:
            abs_idxs = []
        # piggyback “selected_features” like your original did
        self.final_model.selected_features = abs_idxs
        return self

    def predict(self, X):
        if self.final_model is None:
            return cp.zeros(len(X), dtype=cp.float32)   # or cp.float64 if you prefer

        X_cp = cp.asarray(X)

        # rebuild poly features and select the same columns
        if hasattr(self.final_model, "selected_features") and len(self.final_model.selected_features) > 0:
            X_poly, _ = self._gpu_poly_features(X_cp, self.max_degree, include_bias=False)
            abs_idxs = self.final_model.selected_features
            if len(abs_idxs) > 0 and max(abs_idxs) < X_poly.shape[1]:
                X_selected = X_poly[:, abs_idxs]
                return self.final_model.predict(X_selected)  # returns NumPy
        # fallback: predict on raw X
        return self.final_model.predict(X_cp)

    # ---------- helpers ----------
    def _filter_by_interaction_order(self, feature_names):
        """Keep features whose monomial uses ≤ max_interaction_order unique variables."""
        valid = []
        for i, name in enumerate(feature_names):
            # names look like: 'x0', 'x1^2', 'x0 x1', 'x0^2 x2', etc.
            var_matches = re.findall(r'x(\d+)', name)
            if len(set(var_matches)) <= self.max_interaction_order:
                valid.append(i)
        return valid

    def _vectorized_forward_selection(self, X_cand, y_cp):
        return _vectorized_forward_selection(X_cand, y_cp, self.tolerance, self.verbose)

    def _batch_evaluate_candidates(self, X_cand, y_cp, selected, remaining):
        """Evaluate a batch of candidates by k-fold R², stays on GPU for data/fit."""
        scores = []
        X_sel = X_cand[:, selected] if selected else None

        for cand in remaining:
            # assemble [selected | candidate]
            X_test = X_cand[:, [cand]] if X_sel is None else cp.concatenate([X_sel, X_cand[:, [cand]]], axis=1)
            score = _fast_cv_score(X_test, y_cp, cv_folds=3)
            scores.append(score)

        return cp.asarray(scores, dtype=cp.float32)

    def _fast_cv_score(self, X_cp, y_cp, cv_folds=3):
        return _fast_cv_score(X_cp, y_cp, cv_folds)

    # ---------- GPU polynomial features ----------
    @staticmethod
    def _gpu_poly_features(X_cp: cp.ndarray, degree: int, include_bias: bool = False):
        return gpu_poly_features(X_cp, degree, include_bias)


class VectorizedMAPS:
    """Vectorized Multiplicative Polynomial Selection (GPU: CuPy + Torch OLS)"""

    def __init__(self, max_degree=3, max_interaction_order=2, tolerance=1e-4, verbose=False):
        self.max_degree = int(max_degree)
        self.max_interaction_order = int(max_interaction_order)
        self.tolerance = float(tolerance)
        self.verbose = verbose
        self.selected_features = None
        self.final_model = None
        self.location_shift = 0.0
        self.quantile_remapper = None
        self._feature_names_all = None
        self._candidate_indices = None

    def fit(self, X, y):
        # move to GPU
        X_cp = cp.asarray(X)
        y_cp = cp.asarray(y).reshape(-1)

        # ensure positivity -> log space
        y_min = float(cp.min(y_cp))
        if y_min <= 0.0:
            self.location_shift = abs(y_min) + 1.0
            y_pos = y_cp + self.location_shift
        else:
            self.location_shift = 0.0
            y_pos = y_cp
        log_y_cp = cp.log(y_pos)

        # quantile remap (for interpretability) on GPU
        self.quantile_remapper = QuantileRemapper().fit(X_cp)
        X_remapped = self.quantile_remapper.transform(X_cp)

        # polynomial features on remapped variables (GPU)
        X_poly, feat_names = self._gpu_poly_features(X_remapped, self.max_degree, include_bias=False)
        self._feature_names_all = feat_names

        # filter by interaction order
        candidate_indices = self._filter_by_interaction_order(feat_names)
        if len(candidate_indices) == 0:
            candidate_indices = list(range(min(X_cp.shape[1], X_poly.shape[1])))
        self._candidate_indices = candidate_indices

        X_cand = X_poly[:, candidate_indices]

        # forward selection in log space
        self.selected_features = self._vectorized_forward_selection(X_cand, log_y_cp)

        # final fit in log space (selected poly -> log_y)
        if self.selected_features and len(self.selected_features) > 0:
            X_final = X_cand[:, self.selected_features]
        else:
            # fallback: use remapped main effects if nothing selected
            X_final = X_remapped

        lr = TorchLinearRegression(fit_intercept=True, device="cuda")
        lr.fit(X_final, log_y_cp)
        self.final_model = lr

        # store absolute poly indices for prediction-time selection
        if self.selected_features and len(self.selected_features) > 0:
            abs_idxs = [candidate_indices[i] for i in self.selected_features]
        else:
            abs_idxs = []
        self.final_model.selected_features = abs_idxs
        return self

    def predict(self, X):
        if self.final_model is None:
            return cp.zeros(len(X), dtype=float)

        X_cp = cp.asarray(X)

        # remap using fitted quantile mapper (fallback: identity)
        if self.quantile_remapper is None:
            X_remapped = X_cp
        else:
            X_remapped = self.quantile_remapper.transform(X_cp)

        # predict in log space, then invert
        if hasattr(self.final_model, "selected_features") and len(self.final_model.selected_features) > 0:
            X_poly, _ = self._gpu_poly_features(X_remapped, self.max_degree, include_bias=False)
            abs_idxs = self.final_model.selected_features
            if len(abs_idxs) > 0 and max(abs_idxs) < X_poly.shape[1]:
                X_sel = X_poly[:, abs_idxs]
                log_y_pred = self.final_model.predict(X_sel)     # NumPy
            else:
                log_y_pred = self.final_model.predict(X_remapped)
        else:
            log_y_pred = self.final_model.predict(X_remapped)

        y_pred = cp.exp(log_y_pred) - self.location_shift
        return y_pred

    # ------------ helpers ------------
    def _filter_by_interaction_order(self, feature_names):
        valid = []
        for i, name in enumerate(feature_names):
            var_matches = re.findall(r'x(\d+)', name)
            if len(set(var_matches)) <= self.max_interaction_order:
                valid.append(i)
        return valid

    def _vectorized_forward_selection(self, X_cand, y_cp):
        return _vectorized_forward_selection(X_cand, y_cp, self.tolerance, self.verbose)

    def _batch_evaluate_candidates(self, X_cand, log_y_cp, selected, remaining):
        scores = []
        X_sel = X_cand[:, selected] if selected else None
        for cand in remaining:
            X_test = X_cand[:, [cand]] if X_sel is None else cp.concatenate([X_sel, X_cand[:, [cand]]], axis=1)
            scores.append(_fast_cv_score(X_test, log_y_cp, cv_folds=3))
        return cp.asarray(scores, dtype=float)

    @staticmethod
    def _gpu_poly_features(X_cp: cp.ndarray, degree: int, include_bias: bool = False):
        return gpu_poly_features(X_cp, degree, include_bias)

class TorchLinearRegression:
    def __init__(
        self,
        fit_intercept: bool = True,
        device: Optional[str] = None,   # None -> 'cuda' if available else 'cpu'
        dtype: torch.dtype = torch.float32,
        solver: str = "lstsq",          # 'lstsq' (robust) or 'normal'
    ):
        self.fit_intercept = fit_intercept
        self.device = device
        self.dtype = dtype
        self.solver = solver

        # learned params exposed as CuPy for your workflow
        self.coef_: Optional["cp.ndarray"] = None          # (n_features,) or (n_targets, n_features)
        self.intercept_: Optional["cp.ndarray"] = None     # () or (n_targets,)

        # internal torch copies
        self._coef_t: Optional[torch.Tensor] = None        # (n_targets, n_features)
        self._intercept_t: Optional[torch.Tensor] = None   # (n_targets,)

    # -------- helpers --------
    def _infer_device(self) -> str:
        if self.device is not None:
            return self.device
        return "cuda" if torch.cuda.is_available() else "cpu"

    @staticmethod
    def _is_cupy(x: Any) -> bool:
        return _HAS_CUPY and (type(x).__module__.split(".")[0] == "cupy")

    @staticmethod
    def _torch_to_cupy(t: torch.Tensor) -> "cp.ndarray":
        if not _HAS_CUPY:
            raise RuntimeError("CuPy is required for cp.ndarray outputs.")
        if t.device.type != "cuda":
            if not torch.cuda.is_available():
                raise RuntimeError("CUDA not available for cp.ndarray output.")
            t = t.to("cuda")
        torch.cuda.synchronize()
        from_dl = getattr(cp, "from_dlpack", None) or getattr(cp, "fromDlpack", None)
        return from_dl(torch_dlpack.to_dlpack(t.detach()))

    @staticmethod
    def _cupy_to_torch_owning(x_cp_src: "cp.ndarray", device: str, dtype: torch.dtype) -> torch.Tensor:
        # make a private, contiguous GPU copy so the original CuPy array remains safe after DLPack handoff
        x_cp = cp.ascontiguousarray(x_cp_src)
        cp.cuda.get_current_stream().synchronize()
        to_dl = getattr(x_cp, "toDlpack", None) or getattr(x_cp, "to_dlpack", None)
        t = torch_dlpack.from_dlpack(to_dl())
        if device:
            t = t.to(device)
        if dtype:
            t = t.to(dtype)
        return t

    def _to_tensor(self, x: _Array, device: str, dtype: torch.dtype) -> torch.Tensor:
        if torch.is_tensor(x):
            return x.to(device=device, dtype=dtype)
        if self._is_cupy(x):
            return self._cupy_to_torch_owning(x, device, dtype)
        raise TypeError(f"Unsupported array type: {type(x)}")

    def _from_tensor(self, t: torch.Tensor) -> "cp.ndarray":
        return self._torch_to_cupy(t)

    # -------- core API --------
    def get_params(self, deep: bool = True) -> Dict[str, Any]:
        return {
            "fit_intercept": self.fit_intercept,
            "device": self.device,
            "dtype": self.dtype,
            "solver": self.solver,
        }

    def set_params(self, **params) -> "TorchLinearRegression":
        for k, v in params.items():
            setattr(self, k, v)
        return self

    def fit(self, X: _Array, y: _Array) -> "TorchLinearRegression":
        dev = self._infer_device()
        X_t = self._to_tensor(X, dev, self.dtype)
        y_t = self._to_tensor(y, dev, self.dtype)

        if y_t.ndim == 1:
            y_t = y_t.unsqueeze(1)

        if self.fit_intercept:
            ones = torch.ones((X_t.shape[0], 1), device=dev, dtype=self.dtype)
            X_aug = torch.cat([X_t, ones], dim=1)
        else:
            X_aug = X_t

        if self.solver == "normal":
            XtX = X_aug.T @ X_aug
            XtX = XtX + 1e-8 * torch.eye(XtX.shape[0], device=dev, dtype=self.dtype)
            Xty = X_aug.T @ y_t
            beta = torch.linalg.solve(XtX, Xty)
        else:
            beta = torch.linalg.lstsq(X_aug, y_t).solution

        if self.fit_intercept:
            w = beta[:-1, :]       # (n_features, n_targets)
            b = beta[-1, :]        # (n_targets,)
        else:
            w = beta
            b = torch.zeros((y_t.shape[1],), device=dev, dtype=self.dtype)

        self._coef_t = w.T.contiguous()      # (n_targets, n_features)
        self._intercept_t = b.contiguous()   # (n_targets,)

        # expose CuPy params
        if y_t.shape[1] == 1:
            self.coef_ = self._from_tensor(self._coef_t)[0]            # (n_features,)
            self.intercept_ = self._from_tensor(self._intercept_t)[0]  # 0-d cp array
        else:
            self.coef_ = self._from_tensor(self._coef_t)               # (n_targets, n_features)
            self.intercept_ = self._from_tensor(self._intercept_t)     # (n_targets,)

        return self

    def predict(self, X: _Array) -> "cp.ndarray":
        if self._coef_t is None or self._intercept_t is None:
            raise RuntimeError("Model is not fitted.")
        dev = self._coef_t.device.type
        X_t = self._to_tensor(X, dev, self._coef_t.dtype)
        y = X_t @ self._coef_t.T
        y = y + (self._intercept_t if self._intercept_t.ndim != 0 else self._intercept_t)
        return self._from_tensor(y.squeeze(-1))

    def score(self, X: _Array, y: _Array) -> float:
        if self._coef_t is None:
            raise RuntimeError("Model is not fitted.")
        dev = self._infer_device()
        X_t = self._to_tensor(X, dev, self._coef_t.dtype)
        y_t = self._to_tensor(y, dev, self._coef_t.dtype)
        if y_t.ndim == 1:
            y_t = y_t.unsqueeze(1)

        y_hat = X_t @ self._coef_t.T
        y_hat = y_hat + (self._intercept_t if self._intercept_t.ndim != 0 else self._intercept_t)

        ss_res = torch.sum((y_t - y_hat) ** 2, dim=0)
        y_mean = torch.mean(y_t, dim=0, keepdim=True)
        ss_tot = torch.sum((y_t - y_mean) ** 2, dim=0).clamp_min(1e-12)
        r2 = 1.0 - (ss_res / ss_tot)
        return float(torch.mean(r2).item())

class QuantileRemapper:
    """Quantile-based variable remapping for MAPS coefficient interpretability (GPU/CuPy)"""

    def __init__(self):
        self.quantile_functions = {}
        self.original_ranges = {}
        self.is_fitted = False

    def _ensure_gpu(self, X):
        if not isinstance(X, cp.ndarray):
            raise TypeError("QuantileRemapper expects a CuPy array (cupy.ndarray).")

    def fit(self, X: cp.ndarray):
        """Fit quantile mapping functions for each variable on GPU"""
        self._ensure_gpu(X)
        self.quantile_functions = {}
        self.original_ranges = {}

        n_features = X.shape[1]
        for i in range(n_features):
            var_data = cp.ascontiguousarray(X[:, i])
            vmin = var_data.min()
            vmax = var_data.max()
            original_range = vmax - vmin
            self.original_ranges[i] = original_range

            sorted_values = cp.sort(var_data)
            n_unique = cp.unique(sorted_values).size

            if n_unique > 1:
                # Map quantiles to (0, original_range]
                target_values = cp.linspace(
                    0.01,
                    (original_range + cp.asarray(0.01, dtype=sorted_values.dtype)),
                    sorted_values.size,
                    dtype=sorted_values.dtype,
                )
                self.quantile_functions[i] = {
                    "source_values": sorted_values,
                    "target_values": target_values,
                }
            else:
                self.quantile_functions[i] = {
                    "source_values": sorted_values,
                    "target_values": cp.zeros_like(sorted_values),
                }

        self.is_fitted = True
        return self

    def transform(self, X: cp.ndarray) -> cp.ndarray:
        """Apply quantile remapping to variables on GPU"""
        if not self.is_fitted:
            raise ValueError("Must fit before transform")
        self._ensure_gpu(X)

        X_remapped = cp.zeros_like(X)
        n_features = X.shape[1]
        for i in range(n_features):
            var_data = cp.ascontiguousarray(X[:, i])
            mapping = self.quantile_functions[i]
            # cp.interp operates on 1D arrays (ascending x assumed)
            remapped = cp.interp(
                var_data.astype(mapping["source_values"].dtype, copy=False),
                mapping["source_values"],
                mapping["target_values"],
            )
            X_remapped[:, i] = remapped.astype(X.dtype, copy=False)

        return X_remapped

    def inverse_transform(self, X_remapped: cp.ndarray) -> cp.ndarray:
        """Inverse quantile remapping back to original scale on GPU"""
        if not self.is_fitted:
            raise ValueError("Must fit before inverse_transform")
        self._ensure_gpu(X_remapped)

        X_original = cp.zeros_like(X_remapped)
        n_features = X_remapped.shape[1]
        for i in range(n_features):
            var_data = cp.ascontiguousarray(X_remapped[:, i])
            mapping = self.quantile_functions[i]
            restored = cp.interp(
                var_data.astype(mapping["target_values"].dtype, copy=False),
                mapping["target_values"],
                mapping["source_values"],
            )
            X_original[:, i] = restored.astype(X_remapped.dtype, copy=False)

        return X_original

