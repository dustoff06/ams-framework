# === GPU-first evaluator (cuML + PyTorch), neutral messaging ===
import torch
import torch.nn as nn
import time
import re
from torch.utils.data import DataLoader, TensorDataset

# Import from your other modules
from .core import VectorizedAPS, VectorizedMAPS, VectorizedAdaptiveMethodSelector
from .utils import gpu_cleanup, gpu_memory_check
from .data_generation import VectorizedBinaryPolynomialFunction

# cuML import
try:
    from cuml.ensemble import RandomForestRegressor as cuRF
    _HAS_CUML = True
except ImportError:
    _HAS_CUML = False
    print("Warning: cuML not available. RF evaluation will fail.")

try:
    import cupy as cp
    _HAS_CUPY = True
except ImportError:
    import numpy as cp  # fallback to NumPy if no GPU
    _HAS_CUPY = False

# --- zero-copy bridges (Torch <-> CuPy) ---
import torch.utils.dlpack as dlpack

def cupy_to_torch(x_cp: cp.ndarray) -> torch.Tensor:
    """Convert CuPy array to PyTorch tensor (version-agnostic)"""
    try:
        # Try new method name first (CuPy >= 9.0)
        if hasattr(x_cp, 'to_dlpack'):
            return dlpack.from_dlpack(x_cp.to_dlpack())
        # Fall back to old method name (CuPy < 9.0)
        elif hasattr(x_cp, 'toDlpack'):
            return dlpack.from_dlpack(x_cp.toDlpack())
        else:
            raise AttributeError("CuPy array has no DLPack method")
    except Exception as e:
        print(f"DLPack conversion failed, using CPU fallback: {e}")
        # CPU fallback (slower but reliable)
        return torch.from_numpy(cp.asnumpy(x_cp)).cuda()

def torch_to_cupy(x_th: torch.Tensor) -> cp.ndarray:
    """Convert PyTorch tensor to CuPy array (version-agnostic)"""
    try:
        # Try new method name first
        if hasattr(cp, 'from_dlpack'):
            return cp.from_dlpack(dlpack.to_dlpack(x_th))
        # Fall back to old method name
        elif hasattr(cp, 'fromDlpack'):
            return cp.fromDlpack(dlpack.to_dlpack(x_th))
        else:
            raise AttributeError("CuPy has no DLPack method")
    except Exception as e:
        print(f"DLPack conversion failed, using CPU fallback: {e}")
        # CPU fallback
        return cp.asarray(x_th.detach().cpu().numpy())

# --- on-GPU R^2 (works on 1-D CuPy arrays) ---
def cp_r2_score(y_true, y_pred):
    # Robust, CuPy-native R^2 that matches the inline formula you debugged
    yt = cp.asarray(y_true, dtype=cp.float32).reshape(-1)
    yp = cp.asarray(y_pred, dtype=cp.float32).reshape(-1)
    if yt.shape != yp.shape:
        raise ValueError(f"cp_r2_score: shape mismatch: {yt.shape} vs {yp.shape}")
    if not cp.isfinite(yt).all() or not cp.isfinite(yp).all():
        return float('nan')  # don’t silently produce nonsense
    ybar   = cp.mean(yt)
    ss_res = cp.sum((yt - yp) ** 2)
    ss_tot = cp.sum((yt - ybar) ** 2)
    return float(1.0 - ss_res / (ss_tot + 1e-12))

# --- a small Torch MLP regressor (GPU) ---
class TorchMLPRegressor(nn.Module):
    def __init__(self, in_dim: int, hidden=(128, 64, 32), dropout=0.2):
        super().__init__()
        layers = []
        last = in_dim
        
        for i, h in enumerate(hidden):
            layers += [
                nn.Linear(last, h),
                nn.BatchNorm1d(h),  # ✅ Helps with training stability
                nn.ReLU(),
                nn.Dropout(dropout) if i < len(hidden)-1 else nn.Identity()
            ]
            last = h
        
        layers += [nn.Linear(last, 1)]
        self.net = nn.Sequential(*layers)
        
        # ✅ Better weight initialization
        self.apply(self._init_weights)
    
    def _init_weights(self, m):
        if isinstance(m, nn.Linear):
            torch.nn.init.xavier_uniform_(m.weight)
            m.bias.data.fill_(0.01)

    def fit(self, X_cp: cp.ndarray, y_cp: cp.ndarray,
            epochs=200, batch_size=1024, lr=1e-3, weight_decay=1e-4,
            verbose=False, device=None):
        if device is None:
            device = "cuda" if torch.cuda.is_available() else "cpu"

        X_th = cupy_to_torch(X_cp).float().to(device)
        y_th = cupy_to_torch(y_cp).float().view(-1, 1).to(device)

        ds = TensorDataset(X_th, y_th)
        dl = DataLoader(ds, batch_size=batch_size, shuffle=True)

        self.to(device)
        opt = torch.optim.Adam(self.parameters(), lr=lr, weight_decay=weight_decay)
        loss_fn = nn.MSELoss()

        try:
            self.train()
            for ep in range(epochs):
                ep_loss = 0.0
                for xb, yb in dl:
                    opt.zero_grad(set_to_none=True)
                    pred = self.net(xb)
                    loss = loss_fn(pred, yb)
                    loss.backward()
                    opt.step()
                    ep_loss += loss.item()  # ✅ More efficient than .detach().cpu()
                
                # Optional: periodic cleanup
                if ep % 50 == 0:
                    torch.cuda.empty_cache()
                    
        finally:
            # ✅ Always cleanup
            torch.cuda.empty_cache()
        
        return self

    @torch.no_grad()
    def predict(self, X_cp: cp.ndarray, device=None) -> cp.ndarray:
        if device is None:
            device = "cuda" if torch.cuda.is_available() else "cpu"
        self.eval().to(device)
        X_th = cupy_to_torch(X_cp).float().to(device)
        pred = self.net(X_th).squeeze(1)
        return torch_to_cupy(pred)

# === Evaluator (neutral language) ===
class ModelEvaluator:
    """
    Compare the interpretable model (AMS) vs GPU baselines (cuML RF, Torch MLP)
    with all computations on GPU where possible.
    """
    def __init__(self, random_state: int = 42):
        self.random_state = random_state
        self.rf_model = None
        self.nn_model = None

    def evaluate_models(self, X_train, X_test, y_train, y_test,
                        ams_model, true_coeffs, feature_info):
        """
        X_*, y_*: CuPy arrays
        ams_model: your fitted VectorizedAPS/VectorizedMAPS wrapper
        """
        results = {}

        # 1) Interpretable model (AMS)
        ams_results = self._evaluate_ams(X_train, X_test, y_train, y_test,
                                         ams_model, true_coeffs, feature_info)
        results.update(ams_results)

        # 2) GPU baselines
        blackbox_results = self._evaluate_gpu_baselines(X_train, X_test, y_train, y_test)
        results.update(blackbox_results)

        # 3) Analysis
        analysis = self._analyze_against_benchmarks(results)
        results.update(analysis)

        return results

    def _evaluate_ams(self, X_train, X_test, y_train, y_test,
                      ams_model, true_coeffs, feature_info):
            # Time AMS predictions
        start_time = time.time()
        ams_pred_test = ams_model.predict(X_test)
        ams_pred_train = ams_model.predict(X_train)
        ams_predict_time = time.time() - start_time

        # Ensure CuPy
        if not isinstance(ams_pred_test, cp.ndarray):
            ams_pred_test = cp.asarray(ams_pred_test)
        if not isinstance(ams_pred_train, cp.ndarray):
            ams_pred_train = cp.asarray(ams_pred_train)

        ams_r2_test = cp_r2_score(y_test, ams_pred_test)
        ams_r2_train = cp_r2_score(y_train, ams_pred_train)
        ams_overfit = ams_r2_train - ams_r2_test

        # Time coefficient recovery
        start_time = time.time()
        coeff_recovery = evaluate_marginal_coefficient_recovery_fixed(
            ams_model, X_train, y_train, true_coeffs,
            feature_info['n_continuous'], feature_info['n_binary']
        )
        coeff_recovery_time = time.time() - start_time

        return {
            'ams_r2': ams_r2_test,
            'ams_r2_train': ams_r2_train,
            'ams_overfit': ams_overfit,
            'ams_method': ams_model.selected_method,

            # interpretability (unchanged schema)
            'ams_coeff_sign_accuracy': coeff_recovery['sign_accuracy'],
            'ams_coeff_magnitude_correlation': coeff_recovery['magnitude_correlation'],
            'ams_coeff_rmse': coeff_recovery['coefficient_rmse'],
            'ams_coeffs_recovered': coeff_recovery['n_compared'],

            # simple interpretability flags
            'ams_strong_interpretability': coeff_recovery['magnitude_correlation'] > 0.9,
            'ams_good_interpretability': coeff_recovery['magnitude_correlation'] > 0.7,
            'ams_interpretability_score': coeff_recovery['magnitude_correlation'],
        }

    def _evaluate_gpu_baselines(self, X_train, X_test, y_train, y_test):
        # --- cuML Random Forest ---
        rf_res = self._eval_rf_cuml(X_train, X_test, y_train, y_test)

        # --- Torch MLP (with simple on-GPU standardization) ---
        nn_res = self._eval_torch_mlp(X_train, X_test, y_train, y_test)

        rf_r2 = float(rf_res.get('rf_r2', float('nan')))
        nn_r2 = float(nn_res.get('nn_r2', float('nan')))
        
        benchmark_r2_max  = max(rf_r2, nn_r2)
        benchmark_r2_mean = (rf_r2 + nn_r2) / 2.0

        out = {}
        out.update(rf_res)
        out.update(nn_res)
        out.update({
            'benchmark_r2_max': benchmark_r2_max,
            'benchmark_r2_mean': benchmark_r2_mean,
            'benchmark_best_method': 'RF' if rf_res['rf_r2'] > nn_res['nn_r2'] else 'NN'
        })
        return out

    def _eval_rf_cuml(self, X_train, X_test, y_train, y_test):
        if not _HAS_CUML:
            return {
                'rf_r2': float('nan'),
                'rf_r2_train': float('nan'),
                'rf_overfit': float('nan'),
                'rf_success': False,
            }
    
        try:
            from cuml.ensemble import RandomForestRegressor as cuRF
            self.rf_model = cuRF(
                n_estimators=100,
                max_depth=10,
                min_samples_split=5,
                min_samples_leaf=2,
                random_state=self.random_state,
                n_streams=8,
            )

            self.rf_model.fit(X_train, y_train)
    
            # Predictions
            rf_pred_test  = self.rf_model.predict(X_test)
            rf_pred_train = self.rf_model.predict(X_train)
    
            # Ensure CuPy arrays for scoring
            rf_pred_test  = cp.asarray(rf_pred_test)
            rf_pred_train = cp.asarray(rf_pred_train)
    
            # R² using your cp_r2_score (same formula as NN)
            rf_r2        = cp_r2_score(y_test,  rf_pred_test)
            rf_r2_train  = cp_r2_score(y_train, rf_pred_train)
            rf_overfit   = float(rf_r2_train - rf_r2)
    
            return {
                'rf_r2': rf_r2,
                'rf_r2_train': rf_r2_train,
                'rf_overfit': rf_overfit,
                'rf_success': True,
            }
    
        except Exception as e:
            print(f"🚨 RF Eval: Exception caught: {type(e).__name__}: {e}")
            import traceback; traceback.print_exc()
            return {
                'rf_r2': float('nan'),
                'rf_r2_train': float('nan'),
                'rf_overfit': float('nan'),
                'rf_success': False,
            }
    
    

    def _eval_torch_mlp(self, X_train, X_test, y_train, y_test):
        try:
            # Ensure proper data types
            X_train = cp.ascontiguousarray(X_train.astype(cp.float32))
            X_test = cp.ascontiguousarray(X_test.astype(cp.float32))
            y_train = cp.ascontiguousarray(y_train.astype(cp.float32))
            y_test = cp.ascontiguousarray(y_test.astype(cp.float32))
    
            # Validate data
            if not cp.all(cp.isfinite(X_train)) or not cp.all(cp.isfinite(y_train)):
                return {
                    'nn_r2': -10.0,
                    'nn_r2_train': -10.0,
                    'nn_overfit': 0.0,
                    'nn_success': False
                }
    
            if X_train.shape[0] < 10:
                return {
                    'nn_r2': -10.0,
                    'nn_r2_train': -10.0,
                    'nn_overfit': 0.0,
                    'nn_success': False
                }
    
            # Force positivity (like MAPS does)
            y_min = float(cp.min(y_train))
            if y_min <= 0.0:
                shift = abs(y_min) + 1.0
                y_train_pos = y_train + shift
                y_test_pos = y_test + shift
            else:
                shift = 0.0
                y_train_pos = y_train
                y_test_pos = y_test
    
            # Train in log-space for multiplicative stability
            y_train_log = cp.log(y_train_pos)
    
            # Standardize features
            mu = cp.mean(X_train, axis=0)
            sigma = cp.std(X_train, axis=0)
            sigma = cp.where(sigma < 1e-6, 1.0, sigma)
            
            Xtr = (X_train - mu) / sigma
            Xte = (X_test - mu) / sigma
    
            # Create and train model
            in_dim = Xtr.shape[1]
            hidden_size = min(64, max(32, in_dim * 4))
            self.nn_model = TorchMLPRegressor(in_dim, hidden=(hidden_size, hidden_size//2))
            
            # Train on log-transformed targets
            self.nn_model.fit(
                Xtr, y_train_log, 
                epochs=250, 
                batch_size=min(512, max(64, X_train.shape[0]//4)), 
                lr=5e-4, 
                weight_decay=1e-5
            )
    
            # Predict in log-space, then back-transform
            log_pred_test = self.nn_model.predict(Xte)
            log_pred_train = self.nn_model.predict(Xtr)
            
            # Back-transform to original scale
            nn_pred_test = cp.exp(log_pred_test) - shift
            nn_pred_train = cp.exp(log_pred_train) - shift
    
            # Validate predictions
            if not cp.all(cp.isfinite(nn_pred_test)) or not cp.all(cp.isfinite(nn_pred_train)):
                return {
                    'nn_r2': -10.0,
                    'nn_r2_train': -10.0,
                    'nn_overfit': 0.0,
                    'nn_success': False
                }
    
            # Calculate R² on original scale
            nn_r2 = cp_r2_score(y_test, nn_pred_test)
            nn_r2_train = cp_r2_score(y_train, nn_pred_train)
            
            # Validate R² values
            if not cp.isfinite(nn_r2):
                nn_r2 = -10.0
            if not cp.isfinite(nn_r2_train):
                nn_r2_train = -10.0
    
            nn_overfit = float(nn_r2_train - nn_r2)
    
            return {
                'nn_r2': float(nn_r2),
                'nn_r2_train': float(nn_r2_train),
                'nn_overfit': nn_overfit,
                'nn_success': True
            }
    
        except Exception as e:
            return {
                'nn_r2': -10.0,
                'nn_r2_train': -10.0,
                'nn_overfit': 0.0,
                'nn_success': False
            }


    def _analyze_against_benchmarks(self, results: dict):
        ams_r2 = results['ams_r2']
        rf_r2 = results['rf_r2']
        nn_r2 = results['nn_r2']
        bmax = results['benchmark_r2_max']
        bmean = results['benchmark_r2_mean']
        interp = results['ams_interpretability_score']

        beats_rf = ams_r2 > rf_r2
        beats_nn = ams_r2 > nn_r2
        beats_best = ams_r2 > bmax
        beats_avg  = ams_r2 > bmean

        gap_vs_rf = ams_r2 - rf_r2
        gap_vs_nn = ams_r2 - nn_r2
        gap_vs_best = ams_r2 - bmax
        gap_vs_avg  = ams_r2 - bmean

        # neutral status tags
        interpretable_and_outperforms = (interp > 0.8) and (ams_r2 > bmax)
        interpretable_and_competitive = (interp > 0.8) and (gap_vs_best > -0.05)  # within 5%

        # simple status level
        if interp > 0.8 and gap_vs_best > 0.02:
            status_level = 'STRONG'
        elif interp > 0.8 and gap_vs_best > -0.02:
            status_level = 'COMPETITIVE'
        elif interp > 0.8 and gap_vs_best > -0.05:
            status_level = 'NEAR'
        elif interp > 0.8:
            status_level = 'INTERPRETABLE_ONLY'
        else:
            status_level = 'WEAK'

        # keep a neutral boolean; also include legacy key for compatibility
        success = status_level in ['STRONG', 'COMPETITIVE']

        return {
            'beats_rf': beats_rf,
            'beats_nn': beats_nn,
            'beats_best': beats_best,
            'beats_avg': beats_avg,

            'gap_vs_rf': gap_vs_rf,
            'gap_vs_nn': gap_vs_nn,
            'gap_vs_best': gap_vs_best,
            'gap_vs_avg': gap_vs_avg,

            'interpretable_and_outperforms': interpretable_and_outperforms,
            'interpretable_and_competitive': interpretable_and_competitive,

            'status_level': status_level,
            'success': success,

            # legacy compatibility fields (you can remove once you update downstream code)
            'ams_beats_rf': beats_rf,
            'ams_beats_nn': beats_nn,
            'ams_beats_best_blackbox': beats_best,
            'ams_beats_avg_blackbox': beats_avg,
            'ams_vs_rf_gap': gap_vs_rf,
            'ams_vs_nn_gap': gap_vs_nn,
            'ams_vs_best_blackbox_gap': gap_vs_best,
            'ams_vs_avg_blackbox_gap': gap_vs_avg,
            'champion_level': status_level,
            'champion_success': success,
        }

# Backward-compat class alias 
InterpretableChampionEvaluator = ModelEvaluator

# === Batch processing (GPU split + neutral logs); keep old name as alias ===

def _process_single_batch_eval(batch):
    """
    GPU-oriented batch loop with systematic memory cleanup.
    """
    batch_results = []
    
    # Initial cleanup
    gpu_cleanup(verbose=True)
    
    for i, (X, y_true, y_noisy, feature_info, config) in enumerate(batch):
        try:
            # Periodic cleanup every 10 experiments
            if i % 10 == 0 and i > 0:
                gpu_cleanup(verbose=True)
                gpu_memory_check(f"Batch progress {i}/{len(batch)}")
            
            n = X.shape[0]
            if n < 20:
                continue

            # GPU train/test split
            rs = cp.random.RandomState(42 + int(config['experiment_id']))
            idx = rs.permutation(n)
            split = int(n * 0.8)
            tr, te = idx[:split], idx[split:]

            X_train, X_test = X[tr], X[te]
            y_train, y_test = y_noisy[tr], y_noisy[te]

            # Fit AMS
            ams_model = VectorizedAdaptiveMethodSelector(
                max_degree=config['degree'],
                max_interaction_order=config['interaction_order'],
                verbose=False
            )
            ams_model.fit(X_train, y_train)

            # True coefficients for interpretability eval
            true_coeffs = VectorizedBinaryPolynomialFunction.get_true_marginal_coefficients_fixed(
                config['n_continuous'], config['n_binary'],
                config['binary_effect_strength'], config['function_type'],
                X_sample=X_train, y_sample=y_train
            )

            evaluator = ModelEvaluator(random_state=42 + int(config['experiment_id']))
            eval_results = evaluator.evaluate_models(
                X_train, X_test, y_train, y_test, ams_model, true_coeffs, feature_info
            )
            
            # ENHANCED REAL-TIME LOGGING WITH METHOD SELECTION
            if i % 10 == 0:
                ams_r2 = eval_results.get('ams_r2', 0)
                rf_r2 = eval_results.get('rf_r2', 0) 
                nn_r2 = eval_results.get('nn_r2', 0)
                status = eval_results.get('status_level', 'UNKNOWN')
                interp = eval_results.get('ams_interpretability_score', 0)
                method = eval_results.get('ams_method', 'UNKNOWN')  # ADD THIS
                
                print(f"    Exp {config['experiment_id']:3d} ({config['function_type']:4s}→{method:4s}): "
                      f"AMS={ams_r2:.3f} RF={rf_r2:.3f} NN={nn_r2:.3f} "
                      f"Status={status} Interp={interp:.3f}")

            # expected method
            expected_method = (
                'APS' if config['function_type'] == 'additive'
                else 'MAPS' if config['function_type'] == 'multiplicative'
                else 'EITHER'
            )
            ams_correct = (ams_model.selected_method == expected_method) or (expected_method == 'EITHER')

            result = dict(config)
            result.update(eval_results)
            result.update({
                'expected_method': expected_method,
                'ams_correct': ams_correct,
                'multiplicative_evidence': ams_model.method_scores['multiplicative_evidence'],
                'interaction_strength': ams_model.method_scores['interaction_strength'],
                'separability': ams_model.method_scores['multiplicative_separability'],
                'dynamic_range': ams_model.method_scores['dynamic_range'],
                'total_features': config['n_continuous'] + config['n_binary'],
                'has_binary': config['n_binary'] > 0,
                'is_mixed_vars': (config['n_continuous'] > 0) and (config['n_binary'] > 0),
                'n_train': int(split),
                'n_test': int(n - split),
            })
            batch_results.append(result)

            # Extra cleanup for memory-intensive mixed functions
            if config['function_type'] == 'mixed':
                del X_train, X_test, y_train, y_test, ams_model, eval_results
                gpu_cleanup()

        except Exception as e:
            print(f"    Error in experiment {config['experiment_id']}: {str(e)[:120]}...")
            # Force cleanup on error
            gpu_cleanup(verbose=True)
            continue

    # Final cleanup
    gpu_cleanup(verbose=True)
    return batch_results

# Backward-compat alias
def _process_single_batch_champion_focused(batch):
    return _process_single_batch_eval(batch)


# === Neutral result analysis (with compat wrapper) ===

# --- tiny helper so code works with both cuDF and pandas ---
def _iter_kv(s):
    """Yield (key, value) pairs from a pandas or cuDF Series without
    forcing a full DataFrame → pandas conversion."""
    # cuDF path
    if hasattr(s, "values_host"):  # cuDF Series
        keys = s.index.to_pandas().tolist()
        vals = s.values_host.tolist()
        return zip(keys, vals)
    # pandas path
    return s.items()

def analyze_results(df):
    """
    GPU-safe printing/summary. Works whether df is cuDF or pandas.
    """
    n = len(df)
    print("\n================ RESULTS SUMMARY ================")
    print(f"Rows: {n}")

    # Example 1: status_level distribution (this was failing)
    level_counts = df["status_level"].value_counts().sort_index()
    print("\nStatus level counts:")
    for level, count in _iter_kv(level_counts):
        pct = 100 * count / max(n, 1)
        print(f"  {str(level):16s}: {int(count)} ({pct:.1f}%)")

    # Example 2: method distribution
    if "ams_method" in df.columns:
        meth_counts = df["ams_method"].value_counts().sort_index()
        print("\nMethod selection counts:")
        for meth, count in _iter_kv(meth_counts):
            pct = 100 * count / max(n, 1)
            print(f"  {str(meth):16s}: {int(count)} ({pct:.1f}%)")

    # Example 3: simple means (cuDF/pandas both fine)
    for col in ["ams_r2", "benchmark_r2_max", "ams_interpretability_score"]:
        if col in df.columns:
            mean_val = float(df[col].mean())  # cuDF returns scalar-like; cast for safety
            print(f"Mean {col}: {mean_val:.4f}")

    return df


# Backward-compat wrapper (so your existing call names still work)
def analyze_interpretable_champion_results(df):
    return analyze_results(df)


def evaluate_marginal_coefficient_recovery(
    ams_model, X_train, y_train, true_coeffs, n_continuous, n_binary
):
    """
    GPU version: fits a main-effects-only model using your GPU APS/MAPS
    and compares recovered coefficients to the known 'true' ones.
    No sklearn; uses the same polynomial naming scheme as the GPU code.
    """
    if ams_model.final_model is None:
        return {
            'sign_accuracy': 0.0,
            'magnitude_correlation': 0.0,
            'coefficient_rmse': cp.inf,
            'n_compared': 0
        }

    # helper to mirror GPU poly naming (degree up to 3)
    def _poly_feature_names(d, degree):
        names = []
        # degree 1
        for j in range(d):
            names.append(f"x{j}")
        if degree >= 2:
            for j in range(d):
                names.append(f"x{j}^2")
            for a in range(d):
                for b in range(a+1, d):
                    names.append(f"x{a} x{b}")
        if degree >= 3:
            for j in range(d):
                names.append(f"x{j}^3")
            for a in range(d):
                for b in range(d):
                    if b == a: 
                        continue
                    names.append(f"x{a}^2 x{b}")
            for a in range(d):
                for b in range(a+1, d):
                    for c in range(b+1, d):
                        names.append(f"x{a} x{b} x{c}")
        return names

    try:
        # Build a main-effects-only GPU model of the same family
        if ams_model.selected_method == 'APS':
            coeff_model = VectorizedAPS(
                max_degree=ams_model.max_degree,
                max_interaction_order=1,   # main effects only
                tolerance=ams_model.tolerance,
                verbose=False
            )
        else:  # MAPS
            coeff_model = VectorizedMAPS(
                max_degree=ams_model.max_degree,
                max_interaction_order=1,   # main effects only
                tolerance=ams_model.tolerance,
                verbose=False
            )

        # Fit on GPU (your GPU classes handle CuPy/Torch internally)
        coeff_model.fit(X_train, y_train)
        inner_model = coeff_model.final_model

        # Map selected poly indices -> names for parsing
        d_total = n_continuous + n_binary
        all_feature_names = _poly_feature_names(d_total, ams_model.max_degree)

        fitted_coeffs = {}

        # Intercept (TorchLinearRegression exposes .intercept_)
        if hasattr(inner_model, 'intercept_'):
            fitted_coeffs['intercept'] = float(inner_model.intercept_)

        selected_features = list(getattr(inner_model, 'selected_features', []) or [])
        model_coeffs = cp.asarray(getattr(inner_model, 'coef_', []), dtype=float)

        if selected_features and model_coeffs.size:
            for i, feat_idx in enumerate(selected_features):
                if i >= model_coeffs.size or feat_idx >= len(all_feature_names):
                    continue
                feature_name = all_feature_names[feat_idx]
                coeff_value = float(model_coeffs[i])

                # Only keep main effects (single unique variable in the term)
                var_matches = re.findall(r'x(\d+)', feature_name)
                unique_vars = set(var_matches)

                if len(unique_vars) <= 1:
                    if '^2' in feature_name and ' ' not in feature_name:
                        # quadratic of a continuous variable
                        var_idx = int(feature_name.split('^')[0][1:])
                        if var_idx < n_continuous:
                            fitted_coeffs[f'x{var_idx}_quadratic'] = coeff_value
                    elif '^3' in feature_name and ' ' not in feature_name:
                        # cubic of a continuous variable
                        var_idx = int(feature_name.split('^')[0][1:])
                        if var_idx < n_continuous:
                            fitted_coeffs[f'x{var_idx}_cubic'] = coeff_value
                    else:
                        # linear/binary main effect
                        if feature_name.startswith('x') and '^' not in feature_name and ' ' not in feature_name:
                            var_idx = int(feature_name[1:])
                            if var_idx < n_continuous:
                                fitted_coeffs[f'x{var_idx}_linear'] = coeff_value
                            else:
                                fitted_coeffs[f'x{var_idx}_binary'] = coeff_value

        # Compare to true coefficients
        common = [k for k in true_coeffs.keys() if k in fitted_coeffs]
        if not common:
            return {
                'sign_accuracy': 0.0,
                'magnitude_correlation': 0.0,
                'coefficient_rmse': cp.inf,
                'n_compared': 0
            }

        true_vals = cp.array([true_coeffs[k] for k in common], dtype=float)
        fit_vals  = cp.array([fitted_coeffs[k] for k in common], dtype=float)

        # drop any NaNs from true values
        mask = ~cp.isnan(true_vals)
        true_vals = true_vals[mask]
        fit_vals  = fit_vals[mask]

        if true_vals.size == 0:
            return {
                'sign_accuracy': 0.0,
                'magnitude_correlation': 0.0,
                'coefficient_rmse': cp.inf,
                'n_compared': 0
            }

        sign_accuracy = float(cp.mean(cp.sign(true_vals) == cp.sign(fit_vals)))

        if true_vals.size > 1:
            mag_corr = cp.corrcoef(cp.abs(true_vals), cp.abs(fit_vals))[0, 1]
            magnitude_corr = float(0.0 if cp.isnan(mag_corr) else mag_corr)
        else:
            rel_err = abs(true_vals[0] - fit_vals[0]) / (abs(true_vals[0]) + 1e-10)
            magnitude_corr = float(max(0.0, 1.0 - rel_err))

        coefficient_rmse = float(cp.sqrt(cp.mean((true_vals - fit_vals) ** 2)))

        return {
            'sign_accuracy': sign_accuracy,
            'magnitude_correlation': magnitude_corr,
            'coefficient_rmse': coefficient_rmse,
            'n_compared': int(true_vals.size)
        }

    except Exception:
        return {
            'sign_accuracy': 0.0,
            'magnitude_correlation': 0.0,
            'coefficient_rmse': cp.inf,
            'n_compared': 0
        }

def evaluate_marginal_coefficient_recovery_fixed(
    ams_model,
    X_train,
    y_train,
    true_coeffs,
    n_continuous,
    n_binary,
    dtype=cp.float32,
):
    """
    GPU version (CuPy):
      - Main-effects polynomial design up to degree D = ams_model.max_degree
      - Continuous vars: powers 1..D
      - Binary vars: linear only (b^k == b), to avoid collinearity
      - MAPS => fit in log-space with positive shift; APS => original space
      - Metrics computed on GPU
    """
    if getattr(ams_model, "final_model", None) is None:
        return {
            'sign_accuracy': 0.0,
            'magnitude_correlation': 0.0,
            'coefficient_rmse': float('inf'),
            'n_compared': 0
        }

    # move data to GPU
    X = cp.asarray(X_train, dtype=dtype)
    y = cp.asarray(y_train, dtype=dtype)

    p_cont = int(n_continuous)
    p_bin  = int(n_binary)
    p      = p_cont + p_bin
    D      = int(getattr(ams_model, "max_degree", 3))

    # ---- build main-effects polynomial design up to degree D ----
    # columns: [1, (for each feature i) x_i^1, x_i^2..x_i^D (continuous only)]
    cols = [cp.ones((X.shape[0], 1), dtype=dtype)]  # intercept

    # continuous variables: powers 1..D
    for i in range(p_cont):
        Xi = X[:, i:i+1]
        # stack powers (1..D)
        powers = [Xi] + [Xi ** k for k in range(2, D + 1)]
        cols.append(cp.concatenate(powers, axis=1))

    # binary variables: linear only to avoid duplicate cols
    for j in range(p_cont, p):
        cols.append(X[:, j:j+1])

    X_poly = cp.concatenate(cols, axis=1)

    # target: MAPS => log-space with shift; APS => original
    if getattr(ams_model, 'selected_method', 'APS') == 'MAPS':
        ymin = float(cp.min(y))
        y_pos = y - ymin + 1.0 if ymin <= 0.0 else y
        t = cp.log(y_pos)
    else:
        t = y

    # ---- solve least squares on GPU ----
    beta, *_ = cp.linalg.lstsq(X_poly, t, rcond=None)

    # ---- map coefficients back to names consistent with your dict ----
    coeffs_rec = {}
    idx = 0

    # intercept
    coeffs_rec['intercept'] = float(beta[idx].item()); idx += 1

    # continuous vars: degrees 1..D
    for i in range(p_cont):
        for k in range(1, D + 1):
            b = float(beta[idx].item()); idx += 1
            if   k == 1: key = f'x{i}_linear'
            elif k == 2: key = f'x{i}_quadratic'
            elif k == 3: key = f'x{i}_cubic'
            else:        key = f'x{i}_power{k}'
            coeffs_rec[key] = b

    # binary vars: linear only
    for j in range(p_cont, p):
        b = float(beta[idx].item()); idx += 1
        coeffs_rec[f'x{j}_binary'] = b  # (linear effect for binary)

    # ---- compare to provided true coefficients (GPU) ----
    common = [k for k in coeffs_rec if (k in true_coeffs) and (true_coeffs[k] is not None)]
    if not common:
        return {
            'sign_accuracy': 0.0,
            'magnitude_correlation': 0.0,
            'coefficient_rmse': float('inf'),
            'n_compared': 0
        }

    tv = cp.asarray([true_coeffs[k] for k in common], dtype=cp.float64)
    fv = cp.asarray([coeffs_rec[k]  for k in common], dtype=cp.float64)

    mask = ~cp.isnan(tv)
    if not bool(mask.any()):
        return {
            'sign_accuracy': 0.0,
            'magnitude_correlation': 0.0,
            'coefficient_rmse': float('inf'),
            'n_compared': 0
        }
    tv = tv[mask]; fv = fv[mask]
    n = int(tv.size)
    if n == 0:
        return {
            'sign_accuracy': 0.0,
            'magnitude_correlation': 0.0,
            'coefficient_rmse': float('inf'),
            'n_compared': 0
        }

    # sign accuracy
    sign_acc = float(cp.mean(cp.sign(tv) == cp.sign(fv)).item())

    # magnitude correlation (abs values); special-case n==1
    if n > 1:
        r = cp.corrcoef(cp.abs(tv), cp.abs(fv))[0, 1]
        mag_corr = float(cp.nan_to_num(r, nan=0.0).item())
    else:
        rel_err = float(cp.abs(tv[0] - fv[0]) / (cp.abs(tv[0]) + 1e-10))
        mag_corr = max(0.0, 1.0 - rel_err)

    # RMSE
    rmse = float(cp.sqrt(cp.mean((tv - fv) ** 2)).item())

    return {
        'sign_accuracy': sign_acc,
        'magnitude_correlation': mag_corr,
        'coefficient_rmse': rmse,
        'n_compared': n
    }

