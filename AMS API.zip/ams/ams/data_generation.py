import cupy as cp
import math

class VectorizedBinaryPolynomialFunction:
    """Vectorized polynomial function generator for batch experiment processing"""
    
# requires: import cupy as cp

    @staticmethod
    def generate_batch_mixed_data(experiment_configs, base_seed: int = 42):
        # set up fast CuPy allocators
        cp.cuda.set_allocator(cp.cuda.MemoryPool().malloc)
        cp.cuda.set_pinned_memory_allocator(cp.cuda.PinnedMemoryPool().malloc)
        _ = cp.random.random((1,), dtype=cp.float32)  # warm up
    
        print(f"🔄 Generating data for {len(experiment_configs)} experiments on GPU (CuPy)…")
    
        batch_data = []
    
        # Group configs (unchanged)
        config_groups = VectorizedBinaryPolynomialFunction._group_similar_configs(experiment_configs)
    
        for group_idx, (_, configs) in enumerate(config_groups.items()):
            if group_idx % 5 == 0:
                print(f"  Processing group {group_idx+1}/{len(config_groups)}")
    
            for config in configs:
                seed = int(base_seed + int(config["experiment_id"]))
                cp.random.seed(seed)
    
                try:
                    # We convert outputs to CuPy so downstream stays on GPU.
                    X, y_true, y_noisy, feature_info = VectorizedBinaryPolynomialFunction._generate_single_experiment(config)
    
                    X = cp.asarray(X, dtype=cp.float32)
                    y_true = cp.asarray(y_true, dtype=cp.float32)
                    y_noisy = cp.asarray(y_noisy, dtype=cp.float32)
    
                    batch_data.append((X, y_true, y_noisy, feature_info, config))
    
                except Exception as e:
                    if group_idx % 10 == 0:
                        print(f"    Error in experiment {config['experiment_id']}: {str(e)[:50]}")
                    continue
    
        cp.cuda.Stream.null.synchronize()
        print(f"✅ Generated data for {len(batch_data)} valid experiments (GPU)")
        return batch_data

    
    @staticmethod
    def _group_similar_configs(configs):
        """Group configurations by similar parameters for batch processing"""
        groups = {}
        for config in configs:
            # Create grouping key based on data generation parameters
            key = (
                config['function_type'],
                config['n_continuous'], 
                config['n_binary'],
                config['degree'],
                tuple(sorted(config['interaction_types']))  # Sort for consistent grouping
            )
            
            if key not in groups:
                groups[key] = []
            groups[key].append(config)
        
        return groups
    
# requires: import cupy as cp

    @staticmethod
    def _generate_single_experiment(config):
        """Generate data for a single experiment on GPU (CuPy)."""
        n_samples        = int(config['n_samples'])
        n_continuous     = int(config['n_continuous'])
        n_binary         = int(config['n_binary'])
        degree           = int(config['degree'])  # kept for parity; not directly used here
        noise_level      = float(config['noise_level'])
        function_type    = config['function_type']
        binary_strength  = float(config['binary_effect_strength'])
        interaction_types= config['interaction_types']
    
        dt = cp.float32
    
        # --- Generate features on GPU ---
        if n_continuous > 0:
            if function_type == 'additive':
                X_cont = cp.random.uniform(-1.0, 1.0, size=(n_samples, n_continuous)).astype(dt)
            else:  # multiplicative or mixed
                X_cont = cp.random.uniform(0.1, 2.0, size=(n_samples, n_continuous)).astype(dt)
        else:
            X_cont = cp.empty((n_samples, 0), dtype=dt)
    
        if n_binary > 0:
            # p=0.4 Bernoulli
            X_bin = cp.random.binomial(1, 0.4, size=(n_samples, n_binary)).astype(dt)
        else:
            X_bin = cp.empty((n_samples, 0), dtype=dt)
    
        # --- Combine features ---
        if n_continuous > 0 and n_binary > 0:
            X = cp.concatenate([X_cont, X_bin], axis=1)
        elif n_continuous > 0:
            X = X_cont
        elif n_binary > 0:
            X = X_bin
        else:
            raise ValueError("Must have at least one feature")
    
        # --- Response generation on GPU ---
        if function_type == 'additive':
            y = cp.zeros(n_samples, dtype=dt)
    
            # continuous main effects
            if n_continuous > 0:
                y += cp.sum(2.0 * X_cont**2 + 1.0 * X_cont, axis=1)
    
            # binary main effects
            if n_binary > 0:
                y += (binary_strength * 3.0) * cp.sum(X_bin, axis=1)
    
            # interactions
            if 'continuous' in interaction_types and n_continuous > 1:
                y += 1.5 * X_cont[:, 0] * X_cont[:, 1]
    
            if 'binary' in interaction_types and n_binary > 1:
                y += (binary_strength * 2.0) * X_bin[:, 0] * X_bin[:, 1]
    
            if 'mixed' in interaction_types and n_continuous > 0 and n_binary > 0:
                y += (binary_strength * 1.8) * X_cont[:, 0] * X_bin[:, 0]
    
            y += 5.0
    
        elif function_type == 'multiplicative':
            y = cp.ones(n_samples, dtype=dt) * 2.0
    
            if n_continuous > 0:
                factors = 1.0 + X_cont + 0.3 * (X_cont**2)
                y *= cp.prod(factors, axis=1)
    
            if n_binary > 0:
                bf = 1.0 + (binary_strength * 0.8) * X_bin
                y *= cp.prod(bf, axis=1)
    
            if 'continuous' in interaction_types and n_continuous > 1:
                y *= (1.0 + 0.2 * X_cont[:, 0] * X_cont[:, 1])
    
            if 'binary' in interaction_types and n_binary > 1:
                y *= (1.0 + (binary_strength * 0.3) * X_bin[:, 0] * X_bin[:, 1])
    
            if 'mixed' in interaction_types and n_continuous > 0 and n_binary > 0:
                y *= (1.0 + (binary_strength * 0.25) * X_cont[:, 0] * X_bin[:, 0])
    
            y *= 1.5
    
        else:  # 'mixed'
            # additive branch
            y_add = cp.zeros(n_samples, dtype=dt)
            if n_continuous > 0:
                y_add += cp.sum(2.0 * X_cont**2 + 1.0 * X_cont, axis=1)
            if n_binary > 0:
                y_add += (binary_strength * 3.0) * cp.sum(X_bin, axis=1)
            if 'continuous' in interaction_types and n_continuous > 1:
                y_add += 1.5 * X_cont[:, 0] * X_cont[:, 1]
            if 'binary' in interaction_types and n_binary > 1:
                y_add += (binary_strength * 2.0) * X_bin[:, 0] * X_bin[:, 1]
            if 'mixed' in interaction_types and n_continuous > 0 and n_binary > 0:
                y_add += (binary_strength * 1.8) * X_cont[:, 0] * X_bin[:, 0]
            y_add += 5.0
    
            # multiplicative branch
            y_mul = cp.ones(n_samples, dtype=dt) * 2.0
            if n_continuous > 0:
                factors = 1.0 + X_cont + 0.3 * (X_cont**2)
                y_mul *= cp.prod(factors, axis=1)
            if n_binary > 0:
                bf = 1.0 + (binary_strength * 0.8) * X_bin
                y_mul *= cp.prod(bf, axis=1)
            if 'continuous' in interaction_types and n_continuous > 1:
                y_mul *= (1.0 + 0.2 * X_cont[:, 0] * X_cont[:, 1])
            if 'binary' in interaction_types and n_binary > 1:
                y_mul *= (1.0 + (binary_strength * 0.3) * X_bin[:, 0] * X_bin[:, 1])
            if 'mixed' in interaction_types and n_continuous > 0 and n_binary > 0:
                y_mul *= (1.0 + (binary_strength * 0.25) * X_cont[:, 0] * X_bin[:, 0])
            y_mul *= 1.5
    
            # normalize & mix
            add_mu, add_sd = cp.mean(y_add), cp.std(y_add) + 1e-8
            mul_mu, mul_sd = cp.mean(y_mul), cp.std(y_mul) + 1e-8
            y_add_n = (y_add - add_mu) / add_sd
            y_mul_n = (y_mul - mul_mu) / mul_sd
            additive_weight = float(config.get('additive_weight', 0.5))
            y = additive_weight * y_add_n + (1.0 - additive_weight) * y_mul_n
            y = y * 3.0 + 10.0
    
        y_true = y.copy()
    
        # --- Noise on GPU ---
        if noise_level > 0.0:
            sigma = float(noise_level) * float(cp.std(y))
            noise = cp.random.normal(0.0, sigma, size=n_samples).astype(dt)
            y_noisy = y + noise
        else:
            y_noisy = y.copy()
    
        # --- Ensure positivity if needed ---
        ymin = float(cp.min(y_noisy))
        if ymin <= 0.0:
            shift = abs(ymin) + 0.1
            y_noisy = y_noisy + cp.asarray(shift, dtype=dt)
            y_true  = y_true  + cp.asarray(shift, dtype=dt)
    
        feature_info = {
            'n_continuous': n_continuous,
            'n_binary': n_binary,
            'continuous_indices': list(range(n_continuous)),
            'binary_indices': list(range(n_continuous, n_continuous + n_binary)),
            'interaction_types': interaction_types,
            'binary_effect_strength': binary_strength,
        }
    
        return X, y_true, y_noisy, feature_info

    
    @staticmethod
    def _generate_continuous_features(n_samples, n_continuous, function_type, dtype=cp.float32, rng=None):
        """Vectorized continuous feature generation on GPU (CuPy)."""
        if n_continuous == 0:
            return cp.empty((n_samples, 0), dtype=dtype)
        rng = rng or cp.random
        if function_type == 'additive':
            return rng.uniform(-1.0, 1.0, size=(n_samples, n_continuous)).astype(dtype)
        else:  # multiplicative or mixed
            return rng.uniform(0.1, 2.0, size=(n_samples, n_continuous)).astype(dtype)
        
    @staticmethod
    def _generate_binary_features(n_samples, n_binary, dtype=cp.int8, rng=None):
        """Vectorized binary feature generation on GPU (CuPy)."""
        if n_binary == 0:
            return cp.empty((n_samples, 0), dtype=dtype)
        rng = rng or cp.random
        return rng.binomial(1, 0.4, size=(n_samples, n_binary)).astype(dtype)
    
    @staticmethod
    def _compute_additive_response(X_cont, X_bin, binary_strength, interaction_types, dtype=cp.float32):
        """Vectorized additive response on GPU (CuPy)."""
        n_samples = X_cont.shape[0] if X_cont.size else X_bin.shape[0]
        y = cp.zeros(n_samples, dtype=dtype)
    
        n_cont = X_cont.shape[1]
        n_bin  = X_bin.shape[1]
    
        # continuous main effects: sum(2*x^2 + 1*x)
        if n_cont > 0:
            y += cp.sum(2.0 * (X_cont.astype(dtype, copy=False) ** 2) +
                        1.0 * X_cont.astype(dtype, copy=False), axis=1)
    
        # binary main effects: sum(binary_strength * 3 * x)
        if n_bin > 0:
            xb = X_bin.astype(dtype, copy=False)
            y += (binary_strength * 3.0) * cp.sum(xb, axis=1)
    
        # interactions
        if 'continuous' in interaction_types and n_cont > 1:
            y += 1.5 * X_cont[:, 0].astype(dtype, copy=False) * X_cont[:, 1].astype(dtype, copy=False)
    
        if 'binary' in interaction_types and n_bin > 1:
            xb = X_bin.astype(dtype, copy=False)
            y += (binary_strength * 2.0) * xb[:, 0] * xb[:, 1]
    
        if 'mixed' in interaction_types and n_cont > 0 and n_bin > 0:
            xb0 = X_bin[:, 0].astype(dtype, copy=False)
            y += (binary_strength * 1.8) * X_cont[:, 0].astype(dtype, copy=False) * xb0
    
        # base level
        y += 5.0
        return y

    @staticmethod
    def _compute_multiplicative_response(X_cont, X_bin, binary_strength, interaction_types, dtype=cp.float32):
        """Vectorized multiplicative response on GPU (CuPy)."""
        n_samples = X_cont.shape[0]
        n_cont = X_cont.shape[1]
        n_bin  = X_bin.shape[1]
    
        Xc = X_cont.astype(dtype, copy=False)
        Xb = X_bin.astype(dtype, copy=False)
    
        y = cp.ones(n_samples, dtype=dtype) * 2.0
    
        # continuous multiplicative factors
        if n_cont > 0:
            factors = 1.0 + Xc + 0.3 * (Xc ** 2)
            y *= cp.prod(factors, axis=1)
    
        # binary multiplicative factors
        if n_bin > 0:
            bf = 1.0 + (binary_strength * 0.8) * Xb
            y *= cp.prod(bf, axis=1)
    
        # interactions
        if 'continuous' in interaction_types and n_cont > 1:
            y *= (1.0 + 0.2 * Xc[:, 0] * Xc[:, 1])
    
        if 'binary' in interaction_types and n_bin > 1:
            y *= (1.0 + (binary_strength * 0.3) * Xb[:, 0] * Xb[:, 1])
    
        if 'mixed' in interaction_types and n_cont > 0 and n_bin > 0:
            y *= (1.0 + (binary_strength * 0.25) * Xc[:, 0] * Xb[:, 0])
    
        y *= 1.5
        return y
    
    @staticmethod
    def _compute_mixed_response(
        X_cont,
        X_bin,
        binary_strength,
        interaction_types,
        additive_weight: float = 0.5,
        dtype=cp.float32,
    ):
        """Vectorized mixed response on GPU (CuPy)."""
        # compute branches on GPU
        y_add = VectorizedBinaryPolynomialFunction._compute_additive_response(
            X_cont, X_bin, binary_strength, interaction_types, dtype=dtype
        ).astype(dtype, copy=False)
    
        y_mul = VectorizedBinaryPolynomialFunction._compute_multiplicative_response(
            X_cont, X_bin, binary_strength, interaction_types, dtype=dtype
        ).astype(dtype, copy=False)
    
        # normalize each branch
        eps    = cp.asarray(1e-8, dtype=dtype)
        add_mu = cp.mean(y_add)
        add_sd = cp.std(y_add) + eps
        mul_mu = cp.mean(y_mul)
        mul_sd = cp.std(y_mul) + eps
    
        y_add_n = (y_add - add_mu) / add_sd
        y_mul_n = (y_mul - mul_mu) / mul_sd
    
        # mix and shift
        aw = float(additive_weight)
        y_mixed = aw * y_add_n + (1.0 - aw) * y_mul_n
        return y_mixed * 3.0 + 10.0

    @staticmethod
    def get_true_marginal_coefficients_fixed(
        n_continuous, n_binary, binary_strength, function_type,
        X_sample=None, y_sample=None, additive_weight=0.5, dtype=cp.float32
    ):
        """
        GPU version: estimate 'true' marginal coefficients by fitting a degree-2
        polynomial model on GPU. For multiplicative: fit in log-space.
        Returns a dict with intercept and main-effect (linear/quadratic) terms only.
        """
        true_coeffs = {}
        p_cont, p_bin = int(n_continuous), int(n_binary)
        p = p_cont + p_bin
    
        # ----- Case 1: additive -> coefficients are known from construction -----
        if function_type == 'additive':
            for i in range(p_cont):
                true_coeffs[f'x{i}_linear'] = 1.0
                true_coeffs[f'x{i}_quadratic'] = 2.0
            for j in range(p_bin):
                true_coeffs[f'x{p_cont + j}_binary'] = float(binary_strength) * 3.0
            true_coeffs['intercept'] = 5.0
            return true_coeffs
    
        # If no sample provided, fall back to the original approximations
        if X_sample is None or y_sample is None:
            if function_type == 'multiplicative':
                true_coeffs['intercept'] = math.log(2.0 * 1.5)
                for i in range(p_cont):
                    true_coeffs[f'x{i}_linear'] = 1.0
                    true_coeffs[f'x{i}_quadratic'] = 0.3
                for j in range(p_bin):
                    true_coeffs[f'x{p_cont + j}_binary'] = float(binary_strength) * 0.8
                return true_coeffs
            else:  # mixed fallback
                for i in range(p_cont):
                    true_coeffs[f'x{i}_linear'] = 1.0
                    true_coeffs[f'x{i}_quadratic'] = 0.5
                for j in range(p_bin):
                    true_coeffs[f'x{p_cont + j}_binary'] = float(binary_strength) * 2.0
                true_coeffs['intercept'] = 10.0
                return true_coeffs
    
        # ----- GPU path with samples -----
        X = cp.asarray(X_sample, dtype=dtype)
        y = cp.asarray(y_sample, dtype=dtype)
    
        # Build degree-2 polynomial design on GPU:
        # Design columns = [1, x_i (all), x_i^2 (continuous only), x_i*x_j (all i<j)]
        cols = [cp.ones((X.shape[0], 1), dtype=dtype)]  # intercept
    
        # linear terms (all variables)
        cols.append(X)
    
        # quadratic terms for continuous only
        if p_cont > 0:
            cols.append(X[:, :p_cont] ** 2)
    
        # pairwise interactions (all i<j)
        if p > 1:
            inter_cols = []
            for i in range(p):
                Xi = X[:, i:i+1]
                for j in range(i+1, p):
                    inter_cols.append(Xi * X[:, j:j+1])
            if inter_cols:
                cols.append(cp.concatenate(inter_cols, axis=1))
    
        X_poly = cp.concatenate(cols, axis=1)
    
        # Target vector: log-space for multiplicative; original y for mixed
        if function_type == 'multiplicative':
            ymin = float(cp.min(y))
            y_pos = y - ymin + 1.0 if ymin <= 0.0 else y
            t = cp.log(y_pos)
        else:  # 'mixed'
            t = y
    
        # Solve least squares on GPU
        # beta shape: (n_features,)
        beta, *_ = cp.linalg.lstsq(X_poly, t, rcond=None)
    
        # Map back to main effects
        # index layout:
        #   0                      -> intercept
        #   1 .. p                 -> linear terms x0..x{p-1}
        #   p+1 .. p+p_cont        -> quadratic terms (continuous only): x0^2..x{p_cont-1}^2
        #   remaining              -> interactions (ignored for marginal coeffs)
        idx = 0
        intercept = float(beta[idx].item()); idx += 1
    
        # linear
        for i in range(p):
            true_coeffs[f'x{i}_linear' if i < p_cont else f'x{i}_binary'] = float(beta[idx + i].item())
        idx += p
    
        # quadratic (continuous only)
        for i in range(p_cont):
            true_coeffs[f'x{i}_quadratic'] = float(beta[idx + i].item())
        idx += p_cont
    
        true_coeffs['intercept'] = intercept
        return true_coeffs
