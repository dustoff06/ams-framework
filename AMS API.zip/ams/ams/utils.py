"""
Utility functions for GPU operations and memory management.
"""

import cupy as cp
import re
import time

def gpu_poly_features(X_cp: cp.ndarray, degree: int, include_bias: bool = False):
    """
    Build polynomial features up to `degree` on GPU - SHARED FUNCTION
    """
    n, d = int(X_cp.shape[0]), int(X_cp.shape[1])
    
    # Pre-calculate total features
    n_features = d  # degree 1
    if degree >= 2:
        n_features += d + (d * (d - 1)) // 2
    if degree >= 3:
        n_features += d + d * (d - 1) + (d * (d - 1) * (d - 2)) // 6
    if include_bias:
        n_features += 1
    
    # Pre-allocate and fill in-place (from previous optimization)
    X_poly = cp.empty((n, n_features), dtype=X_cp.dtype)
    names = []
    idx = 0
    
    if include_bias:
        X_poly[:, idx] = 1.0
        names.append("1")
        idx += 1
    
    # degree 1
    for j in range(d):
        X_poly[:, idx] = X_cp[:, j]
        names.append(f"x{j}")
        idx += 1
    
    if degree >= 2:
        for j in range(d):
            X_poly[:, idx] = X_cp[:, j] ** 2
            names.append(f"x{j}^2")
            idx += 1
        for a in range(d):
            for b in range(a + 1, d):
                X_poly[:, idx] = X_cp[:, a] * X_cp[:, b]
                names.append(f"x{a} x{b}")
                idx += 1
    
    if degree >= 3:
        for j in range(d):
            X_poly[:, idx] = X_cp[:, j] ** 3
            names.append(f"x{j}^3")
            idx += 1
        for a in range(d):
            x_a_sq = X_cp[:, a] ** 2
            for b in range(d):
                if b == a:
                    continue
                X_poly[:, idx] = x_a_sq * X_cp[:, b]
                names.append(f"x{a}^2 x{b}")
                idx += 1
        for a in range(d):
            for b in range(a + 1, d):
                for c in range(b + 1, d):
                    X_poly[:, idx] = X_cp[:, a] * X_cp[:, b] * X_cp[:, c]
                    names.append(f"x{a} x{b} x{c}")
                    idx += 1
    
    return X_poly, names

def _fast_cv_score(X_cp, y_cp, cv_folds=3):
    """Fast CV R² using pre-allocated folds - SHARED FUNCTION"""
    # Import here to avoid circular imports
    from .core import TorchLinearRegression
    
    n, p = int(X_cp.shape[0]), int(X_cp.shape[1])
    if p >= 0.8 * n or n < 15:
        return -10.0

    k = int(min(cv_folds, max(2, n // 10)))
    
    # Create folds ONCE and reuse indices
    cp.random.seed(42)
    idx = cp.arange(n)
    cp.random.shuffle(idx)  # In-place shuffle instead of permutation
    
    fold_size = n // k
    r2s = []
    
    for i in range(k):
        # Use slicing instead of fancy indexing where possible
        val_start = i * fold_size
        val_end = (i + 1) * fold_size if i < k - 1 else n
        
        # Create boolean mask for faster indexing
        val_mask = cp.zeros(n, dtype=bool)
        val_mask[val_start:val_end] = True
        train_mask = ~val_mask
        
        X_tr = X_cp[train_mask]
        y_tr = y_cp[train_mask]
        X_va = X_cp[val_mask]
        y_va = y_cp[val_mask]
        
        # Fast linear regression
        lr = TorchLinearRegression(fit_intercept=True, device="cuda")
        lr.fit(X_tr, y_tr)
        y_hat = lr.predict(X_va)
        
        y_mean = cp.mean(y_va, axis=0, keepdims=True)
        ss_res = cp.sum((y_va - y_hat) ** 2, axis=0)
        ss_tot = cp.sum((y_va - y_mean) ** 2, axis=0) + 1e-12
        r2 = 1.0 - (ss_res / ss_tot)
        r2_scalar = cp.mean(r2)
        
        if bool(cp.isfinite(r2_scalar).item()):
            r2s.append(r2_scalar)
    
    return float(cp.mean(cp.asarray(r2s, dtype=cp.float32)).item()) if r2s else -10.0

def _vectorized_forward_selection(X_cand, y_cp, tolerance=1e-4, verbose=False):
    """Greedy forward selection using GPU-backed CV R² - SHARED FUNCTION"""
    if X_cand.shape[1] == 0:
        return []

    n_candidates = X_cand.shape[1]
    selected = []
    remaining = list(range(n_candidates))
    best_score = -cp.inf
    no_improve = 0

    # More aggressive limits (from previous optimization)
    n = int(X_cand.shape[0])
    if n < 15:
        return selected

    while (remaining and no_improve < 2 and len(selected) < min(15, n_candidates) 
           and len(selected) < n // 10):
        
        scores = _batch_evaluate_candidates(X_cand, y_cp, selected, remaining)
        if len(scores) == 0:
            break

        best_idx = int(cp.argmax(scores))
        best_cand = remaining[best_idx]
        cand_score = float(scores[best_idx])

        if cand_score > best_score + tolerance:
            selected.append(best_cand)
            remaining.pop(best_idx)
            best_score = cand_score
            no_improve = 0
            if verbose:
                print(f"Selected feature {best_cand}, CV R²={best_score:.4f}")
        else:
            no_improve += 1

    return selected

def _batch_evaluate_candidates(X_cand, y_cp, selected, remaining):
    """Evaluate batch of candidates - SHARED FUNCTION"""
    scores = []
    X_sel = X_cand[:, selected] if selected else None

    for cand in remaining:
        X_test = X_cand[:, [cand]] if X_sel is None else cp.concatenate([X_sel, X_cand[:, [cand]]], axis=1)
        score = _fast_cv_score(X_test, y_cp, cv_folds=3)
        scores.append(score)

    return cp.asarray(scores, dtype=cp.float32)

def gpu_cleanup(verbose=False):
    """Force GPU memory cleanup."""
    try:
        cp.cuda.get_current_stream().synchronize()
        cp.get_default_memory_pool().free_all_blocks()
        if verbose:
            print("GPU cleanup completed")
    except Exception as e:
        if verbose:
            print(f"GPU cleanup failed: {e}")

def gpu_memory_check(label=""):
    """Quick GPU memory status check using device memory info."""
    try:
        device = cp.cuda.Device()
        free_bytes, total_bytes = device.mem_info
        used_bytes = total_bytes - free_bytes
        
        used_mb = used_bytes / (1024**2)
        free_mb = free_bytes / (1024**2)
        total_mb = total_bytes / (1024**2)
        
        print(f"GPU Memory {label}: {used_mb:.1f}MB used, {free_mb:.1f}MB free ({total_mb:.1f}MB total)")
        return free_mb
    except Exception as e:
        print(f"GPU memory check failed: {e}")
        return 0

def get_gpu_info():
    """Return GPU information if available (used by __init__.py)."""
    try:
        device = cp.cuda.Device()
        free_bytes, total_bytes = device.mem_info
        return {
            "gpu_available": True,
            "free_memory_mb": free_bytes / (1024**2),
            "total_memory_mb": total_bytes / (1024**2),
            "cupy_version": cp.__version__
        }
    except Exception:
        return {"gpu_available": False}

# Remove the test code - it should go in examples/ instead
# Don't put executable code at module level!