"""
AMS Framework: Adaptive Method Selection for Interpretable Machine Learning

This package provides GPU-accelerated interpretable polynomial modeling with
automatic selection between additive (APS) and multiplicative (MAPS) approaches.
"""

from .core import (
    VectorizedAdaptiveMethodSelector,
    VectorizedAPS, 
    VectorizedMAPS,
    TorchLinearRegression,
    QuantileRemapper
)

from .evaluation import (
    ModelEvaluator,
    evaluate_marginal_coefficient_recovery_fixed
)

from .data_generation import (
    VectorizedBinaryPolynomialFunction
)

from .utils import (
    gpu_poly_features,
    gpu_cleanup,
    gpu_memory_check
)

__version__ = "1.0.0"
__author__ = "Your Name"
__email__ = "your.email@example.com"

__all__ = [
    "VectorizedAdaptiveMethodSelector",
    "VectorizedAPS",
    "VectorizedMAPS", 
    "TorchLinearRegression",
    "QuantileRemapper",
    "ModelEvaluator",
    "evaluate_marginal_coefficient_recovery_fixed",
    "VectorizedBinaryPolynomialFunction",
    "gpu_poly_features",
    "gpu_cleanup", 
    "gpu_memory_check",
]

def get_version():
    """Return the package version."""
    return __version__

def get_gpu_info():
    """Return GPU information if available."""
    try:
        import cupy as cp
        device = cp.cuda.Device()
        free_bytes, total_bytes = device.mem_info
        return {
            "gpu_available": True,
            "free_memory_mb": free_bytes / (1024**2),
            "total_memory_mb": total_bytes / (1024**2),
            "cupy_version": cp.__version__
        }
    except Exception:
        return {"gpu_available": False}