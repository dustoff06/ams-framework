# AMS Framework: Adaptive Method Selection for Interpretable Machine Learning

GPU-accelerated interpretable polynomial modeling with automatic selection between additive (APS) and multiplicative (MAPS) approaches.

## Installation

```bash
pip install ams-framework