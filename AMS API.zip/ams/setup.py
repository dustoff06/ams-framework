from setuptools import setup, find_packages

setup(
    name="ams-framework",
    version="1.0.0",
    author="Sith",
    author_email="fultonl@bc.edu",
    description="Adaptive Method Selection Framework for Interpretable Machine Learning",
    url="https://github.com/dustoff06/ams-framework",
    packages=find_packages(),
    classifiers=[
        "Development Status :: 4 - Beta",
        "Intended Audience :: Science/Research",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
        "Programming Language :: Python :: 3",
        "Topic :: Scientific/Engineering :: Artificial Intelligence",
    ],
    python_requires=">=3.8",
    install_requires=[
        "cupy-cuda12x>=13.5.1",
        "torch>=2.0.0",
        "cudf-cu12>=25.8.0",
        "cuml-cu12>=25.8.0",
        "rmm-cu12>=25.8.0",
        "pandas>=2.3.0",
        "numpy>=2.1.0",
        "scikit-learn>=1.7.0",
        "xgboost>=3.0.0",
        "catboost>=1.2.0",
    ],
)