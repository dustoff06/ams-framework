"""
Basic usage example for the AMS framework.
"""

import cupy as cp
from ams import VectorizedAdaptiveMethodSelector

def main():
    print("AMS Framework Basic Usage Example")
    print("=" * 40)
    
    # Check GPU availability
    from ams import get_gpu_info
    gpu_info = get_gpu_info()
    if not gpu_info["gpu_available"]:
        print("Warning: GPU not available. Performance will be limited.")
        return
    
    print(f"GPU Memory: {gpu_info['free_memory_mb']:.1f}MB free")
    
    # Generate sample additive data
    print("\n1. Generating sample data...")
    cp.random.seed(42)
    n_samples, n_features = 1000, 4
    X = cp.random.uniform(-1, 1, (n_samples, n_features))
    
    # True additive function: y = 2*x0^2 + 1.5*x1 + x2*x3 + noise
    y_true = (2 * X[:, 0]**2 + 1.5 * X[:, 1] + 
              X[:, 2] * X[:, 3] + 5.0)
    y_noisy = y_true + 0.2 * cp.random.normal(0, 1, n_samples)
    
    print(f"Data shape: X={X.shape}, y={y_noisy.shape}")
    
    # Fit AMS model
    print("\n2. Fitting AMS model...")
    ams = VectorizedAdaptiveMethodSelector(
        max_degree=3,
        max_interaction_order=2,
        verbose=True
    )
    ams.fit(X, y_noisy)
    
    print(f"Selected method: {ams.selected_method}")
    
    # Make predictions
    print("\n3. Making predictions...")
    y_pred = ams.predict(X)
    
    # Calculate R²
    ss_res = cp.sum((y_noisy - y_pred) ** 2)
    ss_tot = cp.sum((y_noisy - cp.mean(y_noisy)) ** 2)
    r2 = 1 - (ss_res / ss_tot)
    
    print(f"R² Score: {float(r2):.4f}")
    print(f"Selected features: {len(getattr(ams.final_model, 'selected_features', []))}")
    
    print("\n4. Method selection diagnostics:")
    for key, value in ams.method_scores.items():
        print(f"  {key}: {value:.4f}")

if __name__ == "__main__":
    main()