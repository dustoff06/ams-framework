"""
Script to reproduce a subset of the experimental results.
"""

from ams import VectorizedAdaptiveMethodSelector, VectorizedBinaryPolynomialFunction
from ams import ModelEvaluator
import cupy as cp

def reproduce_single_experiment():
    """Reproduce one experimental configuration."""
    
    config = {
        'function_type': 'additive',
        'n_continuous': 4,
        'n_binary': 2, 
        'degree': 2,
        'interaction_order': 2,
        'noise_level': 0.2,
        'binary_effect_strength': 1.0,
        'n_samples': 1000,
        'experiment_id': 1,
        'replication': 0,
        'interaction_types': ['continuous', 'binary', 'mixed']
    }
    
    print("Reproducing experimental configuration:")
    for key, value in config.items():
        print(f"  {key}: {value}")
    
    # Generate data
    X, y_true, y_noisy, feature_info = (
        VectorizedBinaryPolynomialFunction._generate_single_experiment(config)
    )
    
    # Split data
    n = X.shape[0]
    split = int(0.8 * n)
    X_train, X_test = X[:split], X[split:]
    y_train, y_test = y_noisy[:split], y_noisy[split:]
    
    # Fit AMS
    ams = VectorizedAdaptiveMethodSelector(
        max_degree=config['degree'],
        max_interaction_order=config['interaction_order']
    )
    ams.fit(X_train, y_train)
    
    # Get true coefficients
    true_coeffs = VectorizedBinaryPolynomialFunction.get_true_marginal_coefficients_fixed(
        config['n_continuous'], config['n_binary'],
        config['binary_effect_strength'], config['function_type'],
        X_sample=X_train, y_sample=y_train
    )
    
    # Evaluate
    evaluator = ModelEvaluator(random_state=42)
    results = evaluator.evaluate_models(
        X_train, X_test, y_train, y_test,
        ams, true_coeffs, feature_info
    )
    
    print(f"\nResults:")
    print(f"  Selected method: {results['ams_method']}")
    print(f"  AMS R²: {results['ams_r2']:.4f}")
    print(f"  RF R²: {results['rf_r2']:.4f}")  
    print(f"  NN R²: {results['nn_r2']:.4f}")
    print(f"  Status: {results['status_level']}")
    print(f"  Interpretability: {results['ams_interpretability_score']:.4f}")

if __name__ == "__main__":
    reproduce_single_experiment()